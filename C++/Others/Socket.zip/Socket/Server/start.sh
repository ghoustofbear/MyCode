#!/bin/bash
cmake .
make
./Server
rm cmake_install.cmake
rm CMakeCache.txt
rm -rf CMakeFiles
rm Makefile